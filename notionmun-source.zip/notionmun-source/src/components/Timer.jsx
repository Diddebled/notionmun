import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { createCountdown } from "../utils/countdown";
import { Pause, Play, RotateCcw, SkipForward } from "lucide-react";
import { formatTime } from "../utils/formatTime";
import { createSpeechClock } from "../utils/speechClock";

const MAX_MINUTES = 999;
const MAX_SECONDS = 59;

// Digits only, capped at 3 chars then clamped to MAX_MINUTES. Round-tripping
// through Number/String strips leading zeros, without which typing after
// clearing would prepend ("0" + "3" -> "03") instead of replacing.
function sanitizeMinutesInput(value) {
  const digits = value.replace(/\D/g, "").slice(0, 3);
  if (digits === "") return "0";
  return String(Math.min(MAX_MINUTES, Number(digits)));
}

// Same shape as sanitizeMinutesInput, capped to 2 characters then clamped to
// MAX_SECONDS - "99" is representable in 2 digits but not a valid seconds
// value, so this needs the numeric clamp on top of the length cap.
function sanitizeSecondsInput(value) {
  const digits = value.replace(/\D/g, "").slice(0, 2);
  if (digits === "") return "0";
  return String(Math.min(MAX_SECONDS, Number(digits)));
}

const Timer = forwardRef(function Timer({
  initialTime = 72,
  onComplete = () => {},
  onNext = () => {},
  onAnchorChange = () => {},
  editable = false,
  showNext = false,
  nextDisabled = false,
}, ref) {
  const [seconds, setSeconds] = useState(initialTime);
  const [maxTime, setMaxTime] = useState(initialTime);
  const [running, setRunning] = useState(false);
  const [overtime, setOvertime] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editMinutes, setEditMinutes] = useState("");
  const [editSeconds, setEditSeconds] = useState("");
  const editContainerRef = useRef(null);

  // `onComplete`'s reference is unstable across renders, so a ref lets the
  // animation effect call the latest callback without depending on its
  // identity and restarting.
  const onCompleteRef = useRef(onComplete);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  // Same instability as onCompleteRef above.
  const onAnchorChangeRef = useRef(onAnchorChange);

  useEffect(() => {
    onAnchorChangeRef.current = onAnchorChange;
  }, [onAnchorChange]);

  // Time actually spoken, reported on "next" - the countdown can't answer
  // that once +15s/-15s or an edit has moved it.
  const speechClockRef = useRef(null);
  if (speechClockRef.current === null) speechClockRef.current = createSpeechClock();

  useEffect(() => {
    if (running) speechClockRef.current.start(Date.now());
    else speechClockRef.current.pause(Date.now());
  }, [running]);

  const radius = 150;
  const circumference = 2 * Math.PI * radius;

  const progress = overtime
    ? 0
    : Math.max(0, Math.min(seconds / maxTime, 1));

  const offset = circumference * (1 - progress);

  const ringRef = useRef(null);

  // Wall-clock anchor the animation recomputes from every frame: a
  // setInterval only updates once a second, so a CSS transition just
  // interpolates stale snapshots and any jitter shows. Only user actions move
  // it (see countdown.js), never the rounded per-second display, which used
  // to add a frame back every second.
  const countdownRef = useRef(null);
  if (countdownRef.current === null) countdownRef.current = createCountdown(initialTime);
  const timerStateRef = useRef({ maxTime, overtime });
  timerStateRef.current = { maxTime, overtime };
  useEffect(() => () => {
    const time = Date.now();
    countdownRef.current.pause(time);
    speechClockRef.current.pause(time);
    onAnchorChangeRef.current({ ...countdownRef.current.anchor(), ...timerStateRef.current, running: false });
  }, []);

  // Publishes an anchor to the caller (SessionBoard forwards this to
  // LiveSessionService) only at genuine transition points - start/pause,
  // +-15s, edit, reset, overtime - not on every per-second RAF re-anchor
  // above, which would otherwise write to Firestore roughly once a second
  // for as long as any dais timer runs.
  const broadcastAnchor = (overrides = {}) => {
    const { time, value } = countdownRef.current.anchor();
    onAnchorChangeRef.current({
      time,
      value,
      maxTime: overrides.maxTime ?? maxTime,
      running: overrides.running ?? running,
      overtime: overrides.overtime ?? overtime,
    });
  };

  const publishAnchor = (value, overrides = {}) => {
    countdownRef.current.set(value, Date.now());
    broadcastAnchor(overrides);
  };

  // Stops the countdown at its exact remaining time, fractions included.
  const pauseCountdown = () => {
    if (!running) return;
    countdownRef.current.pause(Date.now());
    broadcastAnchor({ running: false });
  };

  // Same instability as onCompleteRef above - lets the tick effect below call
  // the latest publishAnchor (which closes over this render's maxTime/running/
  // overtime) without those needing to sit in its dependency array and
  // restart the RAF loop every render.
  const publishAnchorRef = useRef(publishAnchor);

  useEffect(() => {
    publishAnchorRef.current = publishAnchor;
  });

  useEffect(() => {
    if (!running) return;

    let frame;

    const tick = () => {
      const value = countdownRef.current.remaining(Date.now());

      if (ringRef.current) {
        const liveProgress = overtime
          ? 0
          : Math.max(0, Math.min(value / maxTime, 1));

        ringRef.current.style.strokeDashoffset = circumference * (1 - liveProgress);
      }

      // Anchored at the true crossing value, not -1, so overtime reads 00:00
      // for its first second and stays in step with the wall clock.
      if (!overtime && value <= 0) {
        setOvertime(true);
        onCompleteRef.current();
        setSeconds(Math.ceil(value));
        publishAnchorRef.current(value, { overtime: true });
      } else {
        const rounded = Math.ceil(value);
        setSeconds((prev) => (prev === rounded ? prev : rounded));
      }

      frame = requestAnimationFrame(tick);
    };

    frame = requestAnimationFrame(tick);

    const ring = ringRef.current;

    return () => {
      cancelAnimationFrame(frame);
      // Drop the imperative override so the attribute-driven (React state)
      // value takes back over for the static, paused rendering.
      if (ring) ring.style.strokeDashoffset = "";
    };
  }, [running, overtime, maxTime, circumference]);

  const addTime = (amount) => {
    const next = Math.max(0, countdownRef.current.remaining(Date.now()) + amount);
    const nextOvertime = next > 0 ? false : overtime;
    if (next > 0) setOvertime(false);
    setSeconds(Math.ceil(next));
    publishAnchor(next, { overtime: nextOvertime });
  };

  // Double-clicking the ring resets by default (SessionBoard's per-speaker
  // timer) - `editable` swaps that for typing a new time directly in place
  // (TimerPage) instead.
  const reset = () => {
    countdownRef.current.pause(Date.now());
    setRunning(false);
    setSeconds(initialTime);
    setMaxTime(initialTime);
    setOvertime(false);
    speechClockRef.current.reset();
    publishAnchor(initialTime, { maxTime: initialTime, running: false, overtime: false });
  };

  function startEditing() {
    const clamped = Math.max(seconds, 0);
    pauseCountdown();
    setRunning(false);
    setEditMinutes(String(Math.min(MAX_MINUTES, Math.floor(clamped / 60))).padStart(2, "0"));
    setEditSeconds(String(clamped % 60).padStart(2, "0"));
    setEditing(true);
  }

  function commitEdit() {
    setEditing(false);

    const minutes = editMinutes === "" ? 0 : Number(editMinutes);
    const secs = editSeconds === "" ? 0 : Number(editSeconds);
    const total = minutes * 60 + secs;
    if (total <= 0) return;

    countdownRef.current.pause(Date.now());
    setRunning(false);
    setSeconds(total);
    setMaxTime(total);
    setOvertime(false);
    publishAnchor(total, { maxTime: total, running: false, overtime: false });
  }

  // Only commits once focus leaves both fields entirely (not when tabbing
  // from minutes to seconds) - checked via relatedTarget rather than a
  // per-field blur, which would commit a half-typed value the instant the
  // minutes field loses focus to the seconds field right next to it.
  function handleEditBlur(event) {
    if (!editContainerRef.current?.contains(event.relatedTarget)) {
      commitEdit();
    }
  }

  function handleEditKeyDown(event) {
    if (event.key === "Enter") commitEdit();
    if (event.key === "Escape") setEditing(false);
  }

  const nextSpeaker = () => {
    const elapsed = speechClockRef.current.elapsed(Date.now());
    reset();
    onNext(elapsed);
  };

  const start = () => {
    if (running) return;
    countdownRef.current.start(Date.now());
    setRunning(true);
    broadcastAnchor({ running: true });
  };

  const toggleRunning = () => {
    if (running) {
      pauseCountdown();
      setRunning(false);
    } else {
      start();
    }
  };

  // Exposes only what the dais keyboard shortcuts need, keeping the timer's
  // internal state encapsulated. triggerNext reuses nextSpeaker so a
  // keyboard advance reports real elapsed time, like the button does.
  useImperativeHandle(ref, () => ({
    toggleRunning,
    start,
    reset,
    triggerNext: nextSpeaker,
  }));

  return (
    <div className="speech-timer flex flex-col items-center gap-12">
      <div
        onDoubleClick={editable ? startEditing : reset}
        className="relative flex h-56 w-56 select-none items-center justify-center sm:h-72 sm:w-72 lg:h-80 lg:w-80"
      >
        <svg
          className="absolute inset-0 h-full w-full"
          viewBox="0 0 320 320"
        >
          <circle
            cx="160"
            cy="160"
            r={radius}
            fill="none"
            stroke="var(--timer-track)"
            strokeWidth="4"
          />

          <circle
            ref={ringRef}
            cx="160"
            cy="160"
            r={radius}
            fill="none"
            stroke={overtime ? "var(--danger)" : "var(--timer-remaining)"}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            transform="rotate(-90 160 160)"
            style={{ transition: running ? "none" : "stroke-dashoffset .2s ease" }}
          />
        </svg>

        <div className="relative text-center">
          {editing ? (
            <div
              ref={editContainerRef}
              onBlur={handleEditBlur}
              className="flex items-baseline justify-center text-[3.25rem] font-light tracking-[-0.06em] text-[var(--app-text)] sm:text-[4.25rem] lg:text-[5.5rem]"
            >
              <input
                type="text"
                inputMode="numeric"
                autoFocus
                value={editMinutes}
                onChange={(event) => setEditMinutes(sanitizeMinutesInput(event.target.value))}
                onFocus={(event) => event.target.select()}
                onKeyDown={handleEditKeyDown}
                className="w-[2em] bg-transparent text-center outline-none"
              />
              <span>:</span>
              <input
                type="text"
                inputMode="numeric"
                value={editSeconds}
                onChange={(event) => setEditSeconds(sanitizeSecondsInput(event.target.value))}
                onFocus={(event) => event.target.select()}
                onKeyDown={handleEditKeyDown}
                className="w-[2em] bg-transparent text-center outline-none"
              />
            </div>
          ) : (
            <div
              className={`text-[3.25rem] font-light tracking-[-0.06em] sm:text-[4.25rem] lg:text-[5.5rem] ${
                overtime ? "text-[var(--danger)]" : "text-[var(--app-text)]"
              }`}
            >
              {formatTime(seconds)}
            </div>
          )}

          <div className="mt-2 text-[10px] uppercase tracking-[0.25em] text-[var(--app-text-faint)]">
            {editing ? "Type a time" : overtime ? "Overtime" : "Remaining"}
          </div>
        </div>
      </div>

      <div className="timer-controls flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
        {!overtime && (
            <button
            onClick={() => addTime(-15)}
            className="w-full rounded-none border border-[var(--app-border)] bg-[var(--app-chip)] px-6 py-4 text-sm uppercase tracking-[0.18em] text-[var(--app-text-secondary)] transition hover:bg-[var(--app-chip-active)] sm:w-auto"
            >
            -15s
            </button>
        )}

        <button
            onClick={toggleRunning}
            className="flex w-full items-center justify-center gap-2 rounded-none border border-[var(--app-border)] bg-[var(--app-cta-bg)] px-6 py-4 text-sm font-semibold uppercase tracking-[0.18em] text-[var(--app-cta-text)] transition hover:bg-[var(--app-cta-hover)] sm:w-auto"
        >
            {running ? <Pause size={16} /> : <Play size={16} />}
            {running ? "Pause" : "Start"}
        </button>

        {overtime && showNext ? (
            <button
            onClick={nextSpeaker}
            className="w-full rounded-none border border-[var(--danger)] bg-[var(--danger)] px-6 py-4 text-sm font-semibold uppercase tracking-[0.18em] text-[var(--app-text)] transition hover:brightness-90 sm:w-auto"
            >
            Next
            </button>
        ) : (
            <button
            onClick={() => addTime(15)}
            className="w-full rounded-none border border-[var(--app-border)] bg-[var(--app-chip)] px-6 py-4 text-sm uppercase tracking-[0.18em] text-[var(--app-text-secondary)] transition hover:bg-[var(--app-chip-active)] sm:w-auto"
            >
            +15s
            </button>
        )}
        </div>
      <div className="flex items-center justify-center gap-2">
        <button className="icon-button" onClick={reset} title="Reset timer" aria-label="Reset timer"><RotateCcw size={18} /></button>
        {showNext && <button className="quiet-button" onClick={nextSpeaker} disabled={nextDisabled}><SkipForward size={17} />Next speaker</button>}
      </div>
    </div>
  );
});

export default Timer;
