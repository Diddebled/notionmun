import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, QrCode, Trash2 } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";

import Logo from "../components/Logo";
import AuthService from "../services/AuthService";
import CloudSessionService, { stableDelegateKey, dayNumberForSession } from "../services/CloudSessionService";
import ConferenceService from "../services/ConferenceService";
import LiveSessionService from "../services/LiveSessionService";
import { appUrl } from "../utils/siteUrl";
import { linkCloudAttendance } from "../hooks/useCloudAttendance";
import { saveRecovery } from "../services/desk";

const PILL = "border border-[var(--app-border)] bg-[var(--app-chip)] px-3 py-2 text-xs uppercase tracking-[0.18em] text-[var(--app-text-secondary)] transition hover:bg-[var(--app-chip-active)]";
const PILL_ACTIVE = "border border-[var(--app-border-active)] bg-[var(--app-chip-active)] px-3 py-2 text-xs uppercase tracking-[0.18em] text-[var(--app-text)] transition";
const ROW = "flex w-full items-center justify-between border border-[var(--app-border)] bg-[var(--app-chip)] px-4 py-3 text-left transition hover:border-[var(--app-border-hover)] hover:bg-[var(--app-chip-active)]";
const PANEL = "border border-[var(--app-border)] bg-[var(--app-panel)] p-6";
const LABEL = "text-xs uppercase tracking-[0.22em] text-[var(--app-text-muted)]";
const INPUT = "mt-3 w-full border border-[var(--app-border)] bg-[var(--app-input)] px-3 py-2 text-sm text-[var(--app-text)] placeholder:text-[var(--app-text-faint)] focus:border-[var(--app-border-focus)] focus:outline-none";

const ATTENDANCE_STATES = ["present", "absent", "present_and_voting"];

function nextAttendanceState(current) {
  const index = ATTENDANCE_STATES.indexOf(current ?? "absent");
  return ATTENDANCE_STATES[(index + 1) % ATTENDANCE_STATES.length];
}

export default function CloudSessionsPage() {
  const [user, setUser] = useState(() => AuthService.getCurrentUser());
  const [authTab, setAuthTab] = useState("google");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [quickLoginUrl, setQuickLoginUrl] = useState(null);
  const [error, setError] = useState(null);

  const [sessions, setSessions] = useState([]);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [newTitle, setNewTitle] = useState("");
  const [newCommitteeId, setNewCommitteeId] = useState(ConferenceService.getActiveCommitteeId() ?? "");

  const [attendance, setAttendance] = useState({});
  const [liveSessionId, setLiveSessionId] = useState(() => LiveSessionService.getActiveSessionId());
  const [newCollaboratorUid, setNewCollaboratorUid] = useState("");
  const [pendingDeleteSessionId, setPendingDeleteSessionId] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [changingBroadcast, setChangingBroadcast] = useState(false);
  const broadcastBusy = useRef(false);
  const attendanceOperations = useRef(new Map());
  const activeRef = useRef(activeSessionId); activeRef.current = activeSessionId;

  useEffect(() => AuthService.subscribe(setUser), []);

  useEffect(() => {
    if (!AuthService.isConfigured()) return;
    AuthService.consumeQuickLoginParams().catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    setSessions([]); setActiveSessionId(null); setQuickLoginUrl(null);
    if (!user) return undefined;
    let current = true;
    CloudSessionService.listMySessions(user.uid).then((items) => { if (current) setSessions(items); }).catch((err) => { if (current) setError(err.message); });
    return () => { current = false; };
  }, [user?.uid]);

  // Cleared on every switch and guarded against late replies, so a slow
  // fetch for the previous session can't show (or be edited as) this one's.
  useEffect(() => {
    setAttendance({});
    if (!activeSessionId) return undefined;
    if (!user) return undefined;
    let current = true;
    const unsubscribe = CloudSessionService.subscribeAttendance(activeSessionId, (value) => { if (current) setAttendance(value); }, (err) => { if (current) { setAttendance({}); setError(err.message); } });
    return () => { current = false; unsubscribe(); };
  }, [activeSessionId, user?.uid]);

  async function handleGoogleSignIn() {
    try {
      setError(null);
      await AuthService.signInWithGoogle();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleEmailSubmit(mode) {
    try {
      setError(null);
      if (mode === "signup") {
        await AuthService.signUpWithEmail(email, password);
      } else {
        await AuthService.signInWithEmail(email, password);
      }
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleGenerateQuickLogin() {
    try {
      setError(null);
      const url = await AuthService.createQuickLoginLink();
      setQuickLoginUrl(url);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleCreateSession() {
    if (!newTitle.trim() || !user) return;
    try {
      setError(null);
      const id = await CloudSessionService.createSession({
        title: newTitle.trim(),
        committeeId: newCommitteeId.trim(),
        ownerId: user.uid,
      });
      setNewTitle("");
      setSessions(await CloudSessionService.listMySessions(user.uid));
      setActiveSessionId(id);
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleCycleAttendance(delegateKey) {
    if (!activeSessionId || !user) return;
    const next = nextAttendanceState(attendance[delegateKey]);
    const target = activeSessionId; const operation = Symbol();
    attendanceOperations.current.set(`${target}:${delegateKey}`, operation);
    setAttendance((prev) => ({ ...prev, [delegateKey]: next }));
    try {
      await CloudSessionService.setAttendance(activeSessionId, delegateKey, next);
    } catch (err) {
      if (activeRef.current !== target || attendanceOperations.current.get(`${target}:${delegateKey}`) !== operation) return;
      setAttendance((prev) => ({ ...prev, [delegateKey]: attendance[delegateKey] }));
      setError(err.message);
    }
  }

  async function handleDeleteSession() {
    if (!pendingDeleteSessionId || !user || isDeleting) return;
    setIsDeleting(true);
    try {
      setError(null);
      await CloudSessionService.deleteSession(pendingDeleteSessionId);
      if (liveSessionId === pendingDeleteSessionId) {
        LiveSessionService.setActiveSessionId(null);
        setLiveSessionId(null);
      }
      if (activeSessionId === pendingDeleteSessionId) {
        setActiveSessionId(null);
        setAttendance({});
      }
      setPendingDeleteSessionId(null);
      setSessions(await CloudSessionService.listMySessions(user.uid));
    } catch (err) {
      setError(err.message);
    } finally {
      setIsDeleting(false);
    }
  }

  // Flips SessionBoard/MotionPage's publish gate for this tab - not scoped
  // to activeSessionId's owner, so a co-chair sitting at the dais can go
  // live too, same as attendance's read/write access.
  async function handleToggleLive() {
    if (broadcastBusy.current || !activeSessionId) return;
    broadcastBusy.current = true; setChangingBroadcast(true); setError(null);
    const next = liveSessionId === activeSessionId ? null : activeSessionId;
    try {
      if (liveSessionId && liveSessionId !== next) {
        if (!(await LiveSessionService.stop(liveSessionId))) throw new Error("Could not stop the previous public broadcast. Check your connection and try again.");
        LiveSessionService.setActiveSessionId(null); setLiveSessionId(null);
      }
      if (next && !(await LiveSessionService.publish(next, { active: true }))) throw new Error("Could not start broadcasting. Check your connection and try again.");
      LiveSessionService.setActiveSessionId(next); setLiveSessionId(next);
    } catch (err) { setError(err.message); }
    finally { broadcastBusy.current = false; setChangingBroadcast(false); }
  }

  async function handleAddCollaborator() {
    if (!activeSessionId || !newCollaboratorUid.trim()) return;
    try {
      setError(null);
      await CloudSessionService.addCollaborator(activeSessionId, newCollaboratorUid.trim());
      setNewCollaboratorUid("");
      setSessions(await CloudSessionService.listMySessions(user.uid));
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleRemoveCollaborator(uid) {
    if (!activeSessionId) return;
    try {
      setError(null);
      await CloudSessionService.removeCollaborator(activeSessionId, uid);
      setSessions(await CloudSessionService.listMySessions(user.uid));
    } catch (err) {
      setError(err.message);
    }
  }

  const roster = ConferenceService.isLoaded() ? ConferenceService.getDelegates() : [];
  const activeSession = sessions.find((session) => session.id === activeSessionId) ?? null;
  const isSessionOwner = activeSession && user && activeSession.ownerId === user.uid;

  return (
    <div className="app-shell min-h-screen bg-[var(--app-bg)] p-8 text-[var(--app-text)]">
      <div className="mx-auto max-w-3xl">

        <header className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/home" className="flex items-center gap-3">
              <Logo compact light />
            </Link>
            <span className="text-xs uppercase tracking-[0.18em] text-[var(--app-text-muted)]">Cloud Sessions</span>
          </div>

          <Link to="/home" className={`flex items-center gap-2 ${PILL}`}>
            <ArrowLeft size={14} /> Back
          </Link>
        </header>

        {error && (
          <div className="mb-6 border border-[rgba(var(--danger-rgb),0.3)] bg-[rgba(var(--danger-rgb),0.1)] p-4 text-sm text-[var(--danger)]">
            {error}
          </div>
        )}

        {!AuthService.isConfigured() && (
          <div className={PANEL}>
            <p className={LABEL}>Cloud sessions unavailable</p>
            <p className="mt-2 text-sm text-[var(--app-text-muted)]">Firebase isn't configured for this deployment.</p>
          </div>
        )}

        {AuthService.isConfigured() && !user && (
          <div className={PANEL}>
            <p className={LABEL}>Sign in</p>

            <div className="mt-4 flex gap-3">
              <button onClick={() => setAuthTab("google")} className={authTab === "google" ? PILL_ACTIVE : PILL}>Google</button>
              <button onClick={() => setAuthTab("email")} className={authTab === "email" ? PILL_ACTIVE : PILL}>Email</button>
              <button onClick={() => setAuthTab("qr")} className={authTab === "qr" ? PILL_ACTIVE : PILL}>QR Code</button>
            </div>

            {authTab === "google" && (
              <button onClick={handleGoogleSignIn} className={`mt-5 ${PILL}`}>
                Sign in with Google
              </button>
            )}

            {authTab === "email" && (
              <div className="mt-5">
                <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className={INPUT} />
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className={INPUT} />
                <div className="mt-3 flex gap-3">
                  <button onClick={() => handleEmailSubmit("signin")} className={PILL}>Log In</button>
                  <button onClick={() => handleEmailSubmit("signup")} className={PILL}>Sign Up</button>
                </div>
              </div>
            )}

            {authTab === "qr" && (
              <div className="mt-5">
                <p className="text-sm text-[var(--app-text-muted)]">
                  Generates a throwaway quick-login account. Scanning the code signs the scanning
                  device in directly &mdash; treat the code like a password and don't share it publicly.
                </p>
                <button onClick={handleGenerateQuickLogin} className={`mt-3 flex items-center gap-2 ${PILL}`}>
                  <QrCode size={14} /> Generate QR Code
                </button>
                {quickLoginUrl && (
                  <div className="mt-4 inline-block bg-white p-4">
                    <QRCodeSVG value={quickLoginUrl} size={180} />
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {user && (
          <>
            <div className={PANEL}>
              <p className={LABEL}>Your account</p>
              <p className="mt-2 text-sm text-[var(--app-text-muted)]">
                Share your UID with a session owner so they can add you as a collaborator.
              </p>
              <p className="mt-3 break-all border border-[var(--app-border)] bg-[var(--app-input)] px-3 py-2 font-mono text-xs text-[var(--app-text-secondary)]">
                {user.uid}
              </p>
            </div>

            <div className={`mt-6 ${PANEL}`}>
              <p className={LABEL}>Sessions</p>

              <div className="mt-4 space-y-2">
                {sessions.map((session) => {
                  const dayNumber = dayNumberForSession(session);
                  return (
                    <div
                      key={session.id}
                      className={ROW + (activeSessionId === session.id ? " border-[var(--app-border-focus)] bg-[var(--app-chip-active)]" : "")}
                    >
                      <button onClick={() => setActiveSessionId(session.id)} className="flex flex-1 items-center justify-between text-left">
                        <span className="font-medium">{session.title}</span>
                        <span className="shrink-0 whitespace-nowrap pl-4 text-xs text-[var(--app-text-muted)]">
                          {session.committeeId}
                          {dayNumber ? ` · Day ${dayNumber}` : ""}
                        </span>
                      </button>
                      {user && session.ownerId === user.uid && (
                        <button
                          onClick={() => setPendingDeleteSessionId(session.id)}
                          aria-label={`Delete ${session.title}`}
                          className="ml-4 shrink-0 text-[var(--app-text-faint)] outline-none transition hover:text-[var(--danger)] focus-visible:text-[var(--danger)]"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>
                  );
                })}
                {sessions.length === 0 && <p className="text-sm text-[var(--app-text-muted)]">No cloud sessions yet.</p>}
              </div>

              <div className="mt-5 flex gap-3">
                <input placeholder="Session title" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="w-full border border-[var(--app-border)] bg-[var(--app-input)] px-3 py-2 text-sm text-[var(--app-text)] placeholder:text-[var(--app-text-faint)] focus:border-[var(--app-border-focus)] focus:outline-none" />
                <input placeholder="Committee ID" value={newCommitteeId} onChange={(e) => setNewCommitteeId(e.target.value)} className="w-full border border-[var(--app-border)] bg-[var(--app-input)] px-3 py-2 text-sm text-[var(--app-text)] placeholder:text-[var(--app-text-faint)] focus:border-[var(--app-border-focus)] focus:outline-none" />
                <button onClick={handleCreateSession} className={PILL}>Create</button>
              </div>
            </div>

            {activeSessionId && isSessionOwner && (
              <div className={`mt-6 ${PANEL}`}>
                <p className={LABEL}>Collaborators</p>
                <p className="mt-2 text-sm text-[var(--app-text-muted)]">
                  Co-chairs get full read/write on this session's attendance, but can't delete the session itself.
                </p>

                <div className="mt-4 space-y-2">
                  {(activeSession.memberIds ?? []).filter((uid) => uid !== activeSession.ownerId).map((uid) => (
                    <div key={uid} className={ROW}>
                      <span className="truncate font-mono text-xs text-[var(--app-text-secondary)]">{uid}</span>
                      <button onClick={() => handleRemoveCollaborator(uid)} className="shrink-0 pl-4 text-xs uppercase tracking-[0.16em] text-[var(--danger)] outline-none transition hover:brightness-125 focus-visible:brightness-125">
                        Remove
                      </button>
                    </div>
                  ))}
                  {(activeSession.memberIds ?? []).filter((uid) => uid !== activeSession.ownerId).length === 0 && (
                    <p className="text-sm text-[var(--app-text-muted)]">No collaborators yet.</p>
                  )}
                </div>

                <div className="mt-5 flex gap-3">
                  <input
                    placeholder="Collaborator's Firebase UID"
                    value={newCollaboratorUid}
                    onChange={(e) => setNewCollaboratorUid(e.target.value)}
                    className="w-full border border-[var(--app-border)] bg-[var(--app-input)] px-3 py-2 text-sm text-[var(--app-text)] placeholder:text-[var(--app-text-faint)] focus:border-[var(--app-border-focus)] focus:outline-none"
                  />
                  <button onClick={handleAddCollaborator} className={PILL}>Add</button>
                </div>
              </div>
            )}

            {activeSessionId && (
              <div className={`mt-6 ${PANEL}`}>
                <p className={LABEL}>Delegate View</p>
                <button className="quiet-button mt-3" onClick={() => { if (!ConferenceService.getActiveCommittee() || !window.confirm("Use this shared session's attendance for the current local committee? Remote attendance will replace local attendance; a recovery point is saved first.")) return; try { saveRecovery("Before connecting shared attendance"); linkCloudAttendance(activeSessionId, ConferenceService.getActiveCommitteeId(), user.uid); setError(null); window.location.href = appUrl("/rollcall"); } catch (err) { setError(err.message); } }}>Connect shared attendance to this committee</button>
                <p className="mt-2 text-sm text-[var(--app-text-muted)]">
                  Delegates scan this to see the live speaker queue, timer, and current motion on
                  their own devices &mdash; no login needed.
                </p>

                <button
                  onClick={handleToggleLive}
                  disabled={changingBroadcast}
                  className={`mt-4 ${liveSessionId === activeSessionId ? PILL_ACTIVE : PILL}`}
                >
                  {liveSessionId === activeSessionId ? "Stop Broadcasting" : "Go Live"}
                </button>

                {liveSessionId === activeSessionId && (
                  <>
                    <p className="mt-4 break-all border border-[var(--app-border)] bg-[var(--app-input)] px-3 py-2 font-mono text-xs text-[var(--app-text-secondary)]">
                      {appUrl(`/s/${activeSessionId}`)}
                    </p>
                    <div className="mt-4 inline-block bg-white p-4">
                      <QRCodeSVG value={appUrl(`/s/${activeSessionId}`)} size={180} />
                    </div>
                  </>
                )}
              </div>
            )}

            {activeSessionId && (
              <div className={`mt-6 ${PANEL}`}>
                <p className={LABEL}>Attendance</p>

                {roster.length === 0 && (
                  <p className="mt-3 text-sm text-[var(--app-text-muted)]">
                    No committee roster loaded in this tab &mdash; upload a workbook on Home to see delegates here.
                  </p>
                )}

                <div className="mt-4 space-y-2">
                  {roster.map((delegate) => {
                    const key = stableDelegateKey(delegate.country);
                    const status = attendance[key] ?? "absent";
                    return (
                      <button key={delegate.id} onClick={() => handleCycleAttendance(key)} className={ROW}>
                        <span className="font-medium">{delegate.countryDisplay || delegate.country}</span>
                        <span className="shrink-0 whitespace-nowrap pl-4 text-xs uppercase tracking-[0.16em] text-[var(--app-text-muted)]">
                          {status.replace(/_/g, " ")}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}

      </div>

      {pendingDeleteSessionId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--app-overlay)] p-6">
          <div className="w-full max-w-md border border-[var(--app-border)] bg-[var(--app-panel)] p-6">
            <div className="flex items-center gap-3">
              <Trash2 size={20} className="text-[var(--app-text-muted)]" />
              <h2 className="text-lg font-medium">Delete this session?</h2>
            </div>

            <p className="mt-4 text-sm text-[var(--app-text-secondary)]">
              This permanently deletes the session and all of its attendance data. This can't be undone.
            </p>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setPendingDeleteSessionId(null)}
                disabled={isDeleting}
                className="flex-1 border border-[var(--app-border)] px-4 py-2.5 text-sm text-[var(--app-text-muted)] transition hover:bg-[var(--app-chip)] disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteSession}
                disabled={isDeleting}
                className="flex-1 border border-[var(--app-border)] bg-[var(--app-cta-bg)] px-4 py-2.5 text-sm font-medium text-[var(--app-cta-text)] transition hover:bg-[var(--app-cta-hover)] disabled:opacity-50"
              >
                {isDeleting ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
